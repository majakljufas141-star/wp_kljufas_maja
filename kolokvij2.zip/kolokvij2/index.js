let broj = prompt("Unesite jedan broj:");
    broj = Number(broj);

    let duplo = broj * 2;

    alert("Unio si broj " + broj + ", a dva puta veći broj je " + duplo);